import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tarifas',
  templateUrl: './tarifas.component.html',
  styleUrls: ['./tarifas.component.less']
})
export class TarifasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
