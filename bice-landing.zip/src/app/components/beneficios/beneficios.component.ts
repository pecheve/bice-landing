import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-beneficios',
  templateUrl: './beneficios.component.html',
  styleUrls: ['./beneficios.component.less']
})
export class BeneficiosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
