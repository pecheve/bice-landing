import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usa-cuenta',
  templateUrl: './usa-cuenta.component.html',
  styleUrls: ['./usa-cuenta.component.less']
})
export class UsaCuentaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
